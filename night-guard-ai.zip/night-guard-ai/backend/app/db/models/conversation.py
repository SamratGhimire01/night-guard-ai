import enum
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, ForeignKeyConstraint, Index, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.database import Base
from app.db.models.mixins import CreatedAtMixin, TenantMixin, UpdatedAtMixin, UUIDPrimaryKeyMixin


class MessageSenderType(str, enum.Enum):
    CUSTOMER = "customer"
    AGENT = "agent"
    STAFF = "staff"


class Conversation(UUIDPrimaryKeyMixin, TenantMixin, CreatedAtMixin, UpdatedAtMixin, Base):
    __tablename__ = "conversations"
    __table_args__ = (
        # Lets HumanHandoff/FollowUp enforce that a conversation_id they reference
        # belongs to the same business_id.
        UniqueConstraint("id", "business_id", name="uq_conversations_id_business_id"),
        # customer_id must belong to the same business_id as this conversation.
        ForeignKeyConstraint(
            ["customer_id", "business_id"],
            ["customers.id", "customers.business_id"],
            name="fk_conversations_customer_same_tenant",
        ),
        # Phase 25a: same tenant-scoped-FK discipline as every other service_id
        # column in this codebase (see Appointment.service_id) — a NULL
        # booking_draft_service_id is not checked (Postgres MATCH SIMPLE),
        # which is the desired behavior while a draft has no service yet.
        ForeignKeyConstraint(
            ["booking_draft_service_id", "business_id"],
            ["services.id", "services.business_id"],
            name="fk_conversations_booking_draft_service_same_tenant",
        ),
        # Same tenant-scoped-FK discipline, for the "what service did the ASSISTANT
        # just recommend" pointer below.
        ForeignKeyConstraint(
            ["booking_draft_offered_service_id", "business_id"],
            ["services.id", "services.business_id"],
            name="fk_conversations_booking_draft_offered_service_same_tenant",
        ),
    )

    # No inline ForeignKey here: the composite fk_conversations_customer_same_tenant
    # constraint below already enforces customer_id -> customers.id.
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True, nullable=False)
    channel: Mapped[str] = mapped_column(String(50), nullable=False)
    status: Mapped[str] = mapped_column(String(50), nullable=False)
    # Phase 7: rolling LLM-generated summary of every message older than the most
    # recent "keep_recent" window (see app/memory/summarization.py). NULL until the
    # conversation first crosses the summarization threshold.
    summary: Mapped[str | None] = mapped_column(Text)
    # How many of this conversation's oldest messages (ordered by created_at) are
    # already folded into `summary` — lets re-summarization pick up only the newly
    # aged-out messages instead of re-summarizing the whole prefix every time.
    summarized_message_count: Mapped[int] = mapped_column(nullable=False, server_default="0")
    # Phase 25: the customer's language+script, locked in once detected (one of
    # ConversationLanguage's values) so every later turn — LLM-drafted or
    # deterministic — stays consistent instead of drifting. Plain string, not a
    # Postgres enum, same "not from the original spec" convention as
    # Message.detected_intent/Conversation.status — ConversationLanguage already
    # constrains it app-side. NULL until the first message with a clear signal.
    detected_language: Mapped[str | None] = mapped_column(String(20))
    # How many consecutive customer messages in a row have used a DIFFERENT
    # language/script than detected_language — orchestrator only actually
    # relocks once this crosses a real threshold (a sustained switch), never on
    # a single stray message. Reset to 0 whenever a message matches the lock.
    language_switch_streak: Mapped[int] = mapped_column(nullable=False, server_default="0")
    # Phase 16: "ask upfront" language mode -- True once this conversation's first reply asked the customer which language
    # they prefer, so the next message is read as the answer (once, never asked twice). Always False in automatic mode.
    language_prompted: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    # Phase 25a: real, persisted slot-tracking for an in-progress single
    # booking (see orchestrator._merge_booking_draft/_resolve_booking_draft).
    # Root-cause fix for an infinite confirmation loop: the LLM's job each
    # turn is now ONLY to report whatever service/date/time THIS message
    # mentions, never to judge whether "enough" has been collected — these
    # three columns are what actually accumulate that across turns, so
    # readiness is a real, deterministic Python check instead of an LLM
    # guess it could hedge on forever. No inline ForeignKey on
    # booking_draft_service_id: the composite
    # fk_conversations_booking_draft_service_same_tenant constraint above
    # already enforces it. date/time stored as the same raw "YYYY-MM-DD"/
    # "HH:MM" strings the LLM extracts and _resolve_booking_datetime already
    # parses — format-validated before being written, never trusted as-is.
    # All three are cleared back to NULL the moment a real booking attempt
    # (success OR failure) actually runs, so a stale slot can never silently
    # resurface for a later, unrelated booking.
    booking_draft_service_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))
    booking_draft_date: Mapped[str | None] = mapped_column(String(10))
    booking_draft_time: Mapped[str | None] = mapped_column(String(5))
    # Real root-cause fix (PHASE_STATUS.md, "silent service switch" ->
    # re-investigating the DATE-switch false positive it originally forced
    # us to exclude): `booking_draft_date` above must mean ONLY "the date
    # the CUSTOMER explicitly stated" (written exclusively by
    # orchestrator._merge_booking_draft from a real booking_request.date) —
    # that's what makes it safe to compare turn-to-turn for a genuine
    # switch. Before this field existed, orchestrator._propose_available_
    # slots ALSO wrote directly into booking_draft_date, as a "search from
    # here" internal bookkeeping default (so a later time-only reply, e.g.
    # "10:30 works", could still resolve a full date+time even though the
    # customer never stated a date) — two genuinely different pieces of
    # state (a customer fact vs. Python's own search anchor) sharing one
    # field, which is exactly what produced the false positive. This column
    # is that search anchor's own real home: written only by
    # _propose_available_slots, read only as a FALLBACK when
    # booking_draft_date is still null (see orchestrator._effective_draft_
    # date) — never itself compared for a "did the customer switch dates"
    # judgment.
    booking_draft_search_anchor_date: Mapped[str | None] = mapped_column(String(10))
    # Real conversation-quality audit finding (PHASE_STATUS.md, §50/"don't
    # create an LLM call for everything"): the real, freshly-computed slot
    # list a "here's what's open" turn just showed the customer (see
    # orchestrator._propose_available_slots), as comma-separated UTC ISO8601
    # timestamps — deliberately ephemeral, one-shot state, NOT a durable part
    # of the booking draft: it exists only so THIS turn's deterministic
    # bare-digit-selection check (orchestrator._resolve_bare_digit_slot_pick)
    # can resolve "2" to a real, known slot without a second LLM round trip.
    # Set only when slots are shown, and always cleared again after the very
    # next turn (whether or not that turn actually was a digit pick) — never
    # left to survive long enough for a much-later, unrelated bare digit to
    # be misread as a stale slot selection.
    booking_draft_proposed_slots: Mapped[str | None] = mapped_column(Text)
    # Real bug found live (Samaj Dental Clinic transcript): a customer asked what a
    # "doctor consultation" was called, the ASSISTANT itself named a specific real
    # service ("Dental Consultation") while answering, the customer then replied with
    # a plain affirmative ("hunxa garau garau" -- yes, do it) that names no service of
    # its own, and the draft stayed service-less -- the agent re-asked "which service?"
    # as if it had never proposed one. `booking_draft_service_id` above is deliberately
    # written ONLY from a real customer-stated slot (see its own docstring on why that
    # separation matters for switch-detection); this is that same discipline applied in
    # reverse -- a distinct field for "Python's own record of what WE suggested", never
    # itself a customer-stated fact. Set every turn from classification.proposed_service
    # (see intent.py rule 14b), fully overwritten (never accumulated) each turn -- a
    # one-shot hint exactly like booking_draft_proposed_slots above, consumed only as a
    # fallback when the customer's very next message doesn't name its own service (see
    # orchestrator._merge_booking_draft's offered-service fallback).
    booking_draft_offered_service_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))
    # Payment-gateway choice: set right after a booking whose deposit could go through either eSewa or Khalti (the
    # business offers both), to the appointment still waiting on the customer's answer. Consumed by the next message
    # that clearly names one gateway (orchestrator._resolve_payment_choice_turn) — cleared then, or if the appointment
    # is no longer a confirmed one with no payment yet. Plain UUID, no FK, same shape as booking_draft_service_id.
    payment_choice_appointment_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))
    # Phase 52: human takeover. While now() < human_takeover_until a staff member owns this conversation and the AI stays
    # silent (the orchestrator stores the customer's message but drafts/sends nothing — see takeover_service). NULL or a
    # past time = the AI is in charge. Set/extended by every staff reply (sliding window), cleared by an explicit hand-back
    # or by resolving the handoff. human_takeover_by is display-only ("Sita is handling this"), hence no tenant-composite FK.
    human_takeover_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    human_takeover_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("business_users.id", ondelete="SET NULL")
    )
    # Phase 52: when staff last opened this conversation in the inbox (shared across staff, not per user). A naive UTC timestamp,
    # deliberately the same kind as messages.created_at so "unread" is a plain column comparison in SQL.
    staff_last_read_at: Mapped[datetime | None] = mapped_column(DateTime())


class Message(UUIDPrimaryKeyMixin, CreatedAtMixin, Base):
    """No business_id: tenant context is inherited via conversation_id."""

    __tablename__ = "messages"
    __table_args__ = (
        # Phase 22: real, DB-level webhook idempotency — see external_message_id
        # below. Named explicitly so downgrade() can drop it by name (the same
        # unnamed-constraint-breaks-downgrade bug Phase 3/18's migrations hit).
        UniqueConstraint("external_message_id", name="uq_messages_external_message_id"),
        UniqueConstraint("conversation_id", "client_msg_id", name="uq_messages_conversation_client_msg_id"),
        # The thread/last-message queries every inbox read does (conversation_id alone was the only index).
        Index("ix_messages_conversation_id_created_at", "conversation_id", "created_at"),
    )

    conversation_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), index=True, nullable=False
    )
    sender_type: Mapped[MessageSenderType] = mapped_column(
        Enum(MessageSenderType, name="message_sender_type"), nullable=False
    )
    content: Mapped[str] = mapped_column(Text, nullable=False)
    # Phase 18: the real Phase 8 ConversationIntent classification for this message
    # (customer messages only — see orchestrator.py), persisted so a later query
    # (follow-up detection) can ask "did this conversation ever show real interest"
    # from real historical data instead of re-classifying or guessing. Plain string,
    # not a Postgres enum, mirroring Conversation.status/HumanHandoff.status's existing
    # "field not from the original Phase 2 spec, don't hard-code its allowed values at
    # the DB level" convention — ConversationIntent already constrains it app-side.
    # NULL for every message that predates this phase (honest: we don't know their
    # intent) and for agent messages (intent is classified from what the CUSTOMER said).
    detected_intent: Mapped[str | None] = mapped_column(String(50))
    # Phase 22: the real external message id a channel's own delivery mechanism
    # assigns (e.g. a WhatsApp Cloud API "wamid...."). NULL for every channel
    # that doesn't have this concept (website widget, the direct testing
    # endpoint). `unique=True` on a nullable column is the real, DB-level
    # idempotency guarantee for at-least-once webhook delivery (Postgres treats
    # multiple NULLs as distinct, so this only ever constrains real, non-null
    # ids) — same discipline as Phase 10/18/19's constraints, not just an
    # application-level check a retry/duplicate webhook could bypass.
    external_message_id: Mapped[str | None] = mapped_column(String(255))
    # Phase 52 (inbox). Who sent a STAFF message (display + audit; NULL for every other sender). SET NULL on user delete so the
    # message history survives. No tenant-composite FK: `messages` has no business_id (tenant is inherited via the
    # conversation), so the service validates the user belongs to the conversation's business.
    sent_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("business_users.id", ondelete="SET NULL")
    )
    # What actually happened when this message was pushed to the customer's channel: "sent" | "simulated" (no real token
    # configured) | "failed" | "suppressed" (a human took over before it went out) | "pending" (a staff reply being sent). NULL = no delivery info (every message
    # before this phase, customer messages, and website-widget AI replies, whose delivery is the HTTP response itself).
    delivery_status: Mapped[str | None] = mapped_column(String(20))
    # The adapter's own status string ("sent wamid=…", "failed: HTTP 400", …) — never a raw provider response body.
    delivery_detail: Mapped[str | None] = mapped_column(String(255))
    # Client-generated idempotency key for a staff reply, so a double-click/retry can't send the same reply twice.
    client_msg_id: Mapped[str | None] = mapped_column(String(64))
